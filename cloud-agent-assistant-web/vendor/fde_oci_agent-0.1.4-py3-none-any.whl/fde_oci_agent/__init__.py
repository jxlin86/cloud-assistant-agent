"""Local OCI Operations agent."""

__version__ = "0.1.4"
