from __future__ import annotations

import hashlib
import json
import re
from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field, model_validator


class Expectation(BaseModel):
    model_config = ConfigDict(extra="forbid")
    path: str
    operator: Literal["exists", "equals", "not_empty", "empty"]
    value: Any = None


class WaitFor(BaseModel):
    model_config = ConfigDict(extra="forbid")
    command: list[str] = Field(min_length=2)
    arguments: list[str] = Field(default_factory=list)
    state_path: str = "data.lifecycle-state"
    success_states: list[str] = Field(min_length=1)
    failure_states: list[str] = Field(default_factory=lambda: ["FAILED", "FAULTY", "ERROR", "CANCELED", "CANCELLED"])


class Step(BaseModel):
    model_config = ConfigDict(extra="forbid")
    id: str = Field(pattern=r"^[a-z][a-z0-9_]{0,39}$")
    purpose: str
    command: list[str] = Field(min_length=2)
    arguments: list[str] = Field(default_factory=list)
    expect: list[Expectation] = Field(default_factory=list)
    wait_for: WaitFor | None = None
    vault_id: str | None = None


class Plan(BaseModel):
    model_config = ConfigDict(extra="forbid")
    summary: str
    phase: Literal["discovery", "action", "verification", "complete"]
    changes: list[str] = Field(default_factory=list)
    questions: list[str] = Field(default_factory=list)
    steps: list[Step] = Field(default_factory=list)

    @model_validator(mode="after")
    def check_steps(self) -> "Plan":
        ids = [step.id for step in self.steps]
        if len(ids) != len(set(ids)):
            raise ValueError("Step identifiers must be unique within a plan.")
        if self.phase == "complete" and self.steps:
            raise ValueError("A complete response cannot include commands.")
        if self.phase == "verification" and (not self.steps or any(not s.expect for s in self.steps)):
            raise ValueError("Every verification step needs an explicit expectation.")
        return self

    def digest(self, connection: dict[str, str]) -> str:
        body = json.dumps({"plan": self.model_dump(), "connection": connection}, sort_keys=True)
        return hashlib.sha256(body.encode()).hexdigest()


def parse_plan(text: str) -> Plan:
    text = text.strip()
    if text.startswith("```"):
        text = re.sub(r"^```(?:json)?\s*|\s*```$", "", text, flags=re.I)
    try:
        return Plan.model_validate_json(text)
    except ValueError as original:
        # Some compatible models wrap otherwise valid JSON in prose. Extract one
        # complete object with the JSON parser, never with eval or brace counting.
        start = text.find("{")
        if start < 0:
            raise original
        try:
            value, end = json.JSONDecoder().raw_decode(text, start)
        except ValueError:
            raise original
        trailing = text[end:]
        if "{" in trailing or "[" in trailing:
            raise ValueError("Model returned multiple or ambiguous JSON objects.") from original
        return Plan.model_validate(value)


def path_parts(path: str) -> list[str]:
    """Dot keys and numeric indices, with optional JSON-quoted property names."""
    if path == "$":
        return []
    if path.startswith("$."):
        path = path[2:]
    parts, position = [], 0
    while position < len(path):
        if path[position] == '"':
            key, position = json.JSONDecoder().raw_decode(path, position)
            if not isinstance(key, str):
                raise ValueError("Quoted assertion keys must be strings.")
        else:
            end = path.find(".", position)
            end = len(path) if end < 0 else end
            key, position = path[position:end], end
            if not key or any(char in key for char in '[]"'):
                raise ValueError("Use dot-separated keys/numeric indices or JSON-quoted keys in assertions.")
        parts.append(key)
        if position < len(path):
            if path[position] != "." or position + 1 == len(path):
                raise ValueError("Invalid assertion path separator.")
            position += 1
    return parts


def at_path(data: Any, path: str) -> Any:
    """Resolve an assertion/binding path without evaluating code."""
    node = data
    for key in path_parts(path):
        if isinstance(node, list):
            node = node[int(key)]
        elif isinstance(node, dict):
            node = node[key]
        else:
            raise TypeError(f"Cannot read field {key!r} from {type(node).__name__}; a projected scalar is addressed with '$'.")
    return node


def verify(data: Any, expectations: list[Expectation]) -> list[str]:
    failures = []
    for item in expectations:
        detail = ""
        try:
            value = at_path(data, item.path)
            passed = {
                "exists": lambda: value is not None,
                "equals": lambda: value == item.value,
                "not_empty": lambda: bool(value),
                "empty": lambda: value == [] or value == {} or value == "",
            }[item.operator]()
            if not passed:
                detail = f" (actual value: {str(value)[:160]!r})"
        except (KeyError, IndexError, ValueError, TypeError):
            passed = False
            detail = " (field is absent or the response has a different structure)"
        if not passed:
            failures.append(f"Expectation failed: {item.path} {item.operator} {item.value!r}{detail}")
    return failures
