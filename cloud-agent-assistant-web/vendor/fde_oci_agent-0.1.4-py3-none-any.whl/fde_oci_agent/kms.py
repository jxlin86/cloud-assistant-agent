"""KMS key CLI contracts and Vault-derived endpoint validation (no API calls)."""
import json
import re
from urllib.parse import urlsplit

from .schema import Step


def is_key_command(command: list[str]) -> bool:
    return command[:3] == ["kms", "management", "key"]


def management_endpoint(vault_id: str, endpoint: str, region: str) -> str:
    from oci.regions import REALMS, REGION_REALMS
    parts = vault_id.split(".")
    if len(parts) != 6 or parts[:2] != ["ocid1", "vault"]:
        raise ValueError("KMS key operations require an actual Vault OCID.")
    realm = REGION_REALMS.get(region)
    if realm is None or parts[2] != realm:
        raise ValueError("The Vault realm must match the selected OCI region.")
    if not re.fullmatch(r"[a-z0-9]+", parts[4]):
        raise ValueError("Invalid Vault endpoint prefix.")
    url = urlsplit(endpoint)
    host = f"{parts[4]}-management.kms.{region}.{REALMS[realm]}"
    if (url.scheme != "https" or url.netloc != host or url.path not in {"", "/"}
            or url.query or url.fragment):
        raise ValueError("Vault management-endpoint must be the HTTPS KMS management host for this Vault and selected region.")
    return f"https://{host}"


def prepare_key(step: Step) -> None:
    if not is_key_command(step.command):
        if step.vault_id is not None:
            raise ValueError("vault_id context is supported only for KMS management key commands.")
        return
    # --vault-id is not an OCI key command option. Keep the Vault selection as
    # application context; the executor supplies its observed management endpoint.
    arguments, index = [], 0
    while index < len(step.arguments):
        arg = step.arguments[index]
        if arg.split("=", 1)[0] == "--vault-id":
            if "=" in arg:
                value = arg.split("=", 1)[1]
            else:
                index += 1
                if index == len(step.arguments):
                    raise ValueError("--vault-id requires a value.")
                value = step.arguments[index]
            if step.vault_id is not None and step.vault_id != value:
                raise ValueError("Conflicting Vault contexts for this KMS key command.")
            step.vault_id = value
        else:
            arguments.append(arg)
        index += 1
    step.arguments = arguments
    if not step.vault_id:
        raise ValueError("KMS key commands require vault_id context. First discover the Vault with kms management vault get (no query) to obtain its management-endpoint; do not pass --endpoint yourself.")
    problems = []
    for index, arg in enumerate(arguments):
        if arg.split("=", 1)[0] != "--key-shape":
            continue
        text = arg.split("=", 1)[1] if "=" in arg else arguments[index + 1] if index + 1 < len(arguments) else ""
        if "{{" in text:
            continue  # Concrete JSON is checked again immediately before execution.
        try:
            shape = json.loads(text)
        except ValueError as exc:
            raise ValueError("--key-shape must be inline JSON with algorithm and length.") from exc
        if not isinstance(shape, dict):
            raise ValueError("--key-shape must be a JSON object.")
        if shape.get("algorithm") == "AES" and (type(shape.get("length")) is not int or shape["length"] not in {16, 24, 32}):
            problems.append("AES key-shape length is in BYTES: AES-256 requires 32, AES-192 requires 24, AES-128 requires 16; length 256 is invalid")
    states = list(step.wait_for.success_states) if step.wait_for else []
    states += [check.value for check in step.expect if check.path == "data.lifecycle-state" and check.operator == "equals"]
    if "ACTIVE" in states:
        problems.append("KMS keys reach ENABLED, not ACTIVE; use success_states [ENABLED] and matching lifecycle assertions")
    if problems:
        raise ValueError("; ".join(problems))
