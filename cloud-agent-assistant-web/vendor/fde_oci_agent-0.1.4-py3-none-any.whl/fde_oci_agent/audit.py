from __future__ import annotations

import json
import re
import sqlite3
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


SENSITIVE_KEY = re.compile(r"password|passphrase|pass_phrase|secret|token|private.?key|key_content|key.?value|api.?key|authorization", re.I)


class Redactor:
    def __init__(self) -> None:
        self.secrets: set[str] = set()

    def add(self, value: str) -> None:
        if value:
            self.secrets.add(value)

    def text(self, text: str) -> str:
        for value in sorted(self.secrets, key=len, reverse=True):
            text = text.replace(value, "[REDACTED]")
        text = re.sub(r"-----BEGIN [^-]*PRIVATE KEY-----.*?-----END [^-]*PRIVATE KEY-----", "[REDACTED PRIVATE KEY]", text, flags=re.S)
        text = re.sub(r"(?i)(Bearer\s+)\S+", r"\1[REDACTED]", text)
        text = re.sub(r'(?i)("(?:[^"\n]*(?:password|secret|token|api[_-]?key|authorization)[^"\n]*)"\s*:\s*)"(?:\\.|[^"\\])*"', r'\1"[REDACTED]"', text)
        text = re.sub(r"(?i)(?<!\{)((?:password|passphrase|api[_-]?key|secret|token)\s*(?:[=:]|\bis\b)\s*)[^\s,;]+", r"\1[REDACTED]", text)
        return text

    def clean(self, value: Any) -> Any:
        if isinstance(value, dict):
            return {str(k): "[REDACTED]" if SENSITIVE_KEY.search(str(k)) else self.clean(v) for k, v in value.items()}
        if isinstance(value, list):
            return [self.clean(v) for v in value]
        if isinstance(value, str):
            return self.text(value)
        return value


class Audit:
    def __init__(self, directory: Path, redactor: Redactor):
        directory.mkdir(parents=True, exist_ok=True)
        self.path = directory / "history.sqlite3"
        self.redactor = redactor
        with sqlite3.connect(self.path) as db:
            db.execute("CREATE TABLE IF NOT EXISTS events (id INTEGER PRIMARY KEY, time TEXT, run_id TEXT, kind TEXT, payload TEXT)")

    def record(self, run_id: str, kind: str, payload: Any) -> None:
        with sqlite3.connect(self.path) as db:
            db.execute("INSERT INTO events(time,run_id,kind,payload) VALUES(?,?,?,?)", (
                datetime.now(timezone.utc).isoformat(), run_id, kind,
                json.dumps(self.redactor.clean(payload), ensure_ascii=False),
            ))

    def recent(self, limit: int = 30) -> list[dict]:
        with sqlite3.connect(self.path) as db:
            rows = db.execute("SELECT time,run_id,kind,payload FROM events ORDER BY id DESC LIMIT ?", (limit,)).fetchall()
        return [{"time": t, "run_id": r, "event": k, "data": json.loads(p)} for t, r, k, p in rows]
