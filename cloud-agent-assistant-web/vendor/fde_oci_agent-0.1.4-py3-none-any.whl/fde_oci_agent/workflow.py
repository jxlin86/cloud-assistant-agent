from __future__ import annotations

import asyncio
import hashlib
import random
import subprocess
import uuid
from dataclasses import dataclass
from typing import Any, Callable

from .audit import Audit, Redactor
from .config import Settings
from .executor import Executor, automatic_syntax_repair, canonical_command, error_preview, is_read, requires_approval, response_preview
from .schema import Plan, Step, verify
from .response_schema import add_list_shape_check, add_read_identity_check, validate_expectation_fields
from .query_validation import validate_query
from .task_inputs import initialize_database_step, prepare_database_create, update_task_inputs, validate_database_create_required
from .polling import prepare_wait, status_step, wait_until_complete
from .kms import prepare_key


@dataclass
class Outcome:
    run_id: str
    status: str
    message: str


@dataclass
class CompletedStep:
    step: Step
    mutation_epoch: int
    config_hash: str


class Workflow:
    def __init__(self, settings: Settings, planner: Any, executor: Executor, audit: Audit,
                 redactor: Redactor, ask: Callable[[str], str] = input, emit: Callable[[str], None] = print):
        self.settings, self.planner, self.executor = settings, planner, executor
        self.audit, self.redactor, self.ask, self.emit = audit, redactor, ask, emit
        self.task_inputs: dict = executor.task_inputs

    def _show(self, plan: Plan, digest: str) -> None:
        connection = self.settings.connection()
        self.emit(f"\n{plan.phase.upper()}: {plan.summary}")
        self.emit(f"Profile: {connection['profile']} | Region: {connection['region']}")
        self.emit(f"Tenancy: {connection['tenancy']}\nDefault compartment: {connection['default_compartment']}")
        for change in plan.changes:
            self.emit("  Change: " + self.redactor.text(change))
        for step in plan.steps:
            command = subprocess.list2cmdline(["oci", *step.command, *step.arguments])
            self.emit(f"  [{step.id}] {step.purpose}\n    {self.redactor.text(command)}")
            if step.vault_id:
                self.emit(f"    Vault: {step.vault_id}")
                self.emit("    Management endpoint: " + str(self.executor.key_endpoint(step, {})))
            if step.expect:
                for check in step.expect:
                    comparison = {"exists": "is present", "equals": "equals", "not_empty": "is not empty", "empty": "is empty"}[check.operator]
                    value = " " + str(check.value) if check.operator == "equals" else ""
                    self.emit(f"    Check: {check.path} {comparison}{value}")
            if step.wait_for:
                wait = step.wait_for
                self.emit("    Wait: " + subprocess.list2cmdline(["oci", *wait.command, *wait.arguments]))
                self.emit(f"    Until: {wait.state_path} in {', '.join(wait.success_states)} (every {self.settings.poll_interval}s; timeout {self.settings.wait_timeout}s)")
        self.emit(f"Connection/output flags are added locally. Plan fingerprint: {digest[:12]}")

    def _approve(self, run_id: str, plan: Plan) -> tuple[bool, str]:
        config_hash = hashlib.sha256(self.settings.config_file.read_bytes()).hexdigest()
        digest = plan.digest(self.settings.connection())
        automatic = bool(plan.steps) and all(not requires_approval(step) for step in plan.steps)
        if automatic:
            self.emit(f"\nRead-only: {plan.summary}")
            self.emit(f"Profile: {self.settings.profile} | Region: {self.settings.region}")
            accepted = True
        else:
            self._show(plan, digest)
            accepted = self.ask("Type ACCEPT to execute this stage, or anything else to cancel: ").strip().upper() == "ACCEPT"
        self._connection_unchanged(config_hash)
        self.audit.record(run_id, "approval", {"accepted": accepted,
                          "mode": "automatic_read_only" if automatic else "human",
                          "plan_hash": digest, "plan": plan.model_dump(), "config_hash": config_hash})
        return accepted, config_hash

    def _connection_unchanged(self, config_hash: str) -> None:
        if hashlib.sha256(self.settings.config_file.read_bytes()).hexdigest() != config_hash:
            raise ValueError("OCI config changed after acceptance. Start a new plan to review the connection.")

    async def _validate_plan(self, plan: Plan, results: dict[str, Any] | None = None) -> None:
        results = {} if results is None else results
        pending: set[str] = set()
        if len(plan.steps) > self.settings.max_steps:
            raise ValueError("The plan exceeds the configured command budget.")
        for step in plan.steps:
            step.command = canonical_command(step.command)
            self.executor.validate_bindings(step, results, pending)
            prepare_key(step)
            prepare_wait(step)
            initialize_database_step(step, self.task_inputs, self.settings.database_defaults)
            self.executor.resolve_metadata(step)
            prepare_database_create(step, self.task_inputs)
            validate_database_create_required(step)
            self.executor.validate(step)
            if step.vault_id:
                # Freeze the selected Vault before showing/accepting the plan.
                step.vault_id = self.executor._resolve(step.vault_id, results)
                self.executor.key_endpoint(step, results)
            validate_query(step)
            validate_expectation_fields(step)
            add_read_identity_check(step)
            add_list_shape_check(step)
            if plan.phase in {"discovery", "verification"} and not is_read(step):
                raise ValueError("Discovery and verification stages may only contain recognized read commands.")
            # Execution requires successful retrieval, rather than trusting a model's citation.
            await self.planner.docs.fetch(step.command)
            if step.wait_for:
                poll = status_step(step)
                self.executor.resolve_metadata(poll)
                self.executor.validate(poll)
                prepare_key(poll)
                self.executor.key_endpoint(poll, results)
                validate_expectation_fields(poll)
                await self.planner.docs.fetch(poll.command)
            pending.add(step.id)

    def _reuse_completed_reads(self, plan: Plan, completed: dict[str, CompletedStep],
                              results: dict[str, Any], mutation_epoch: int) -> tuple[Plan, list[str]]:
        """Reuse exact reads within this run; never silently rerun completed mutations."""
        config_hash = hashlib.sha256(self.settings.config_file.read_bytes()).hexdigest()
        pending, reused = [], []
        read_only_plan = all(is_read(step) for step in plan.steps)
        for step in plan.steps:
            previous = completed.get(step.id)
            if previous is None:
                pending.append(step)
                continue
            identical = (previous.step.command == step.command and previous.step.arguments == step.arguments
                         and previous.step.vault_id == step.vault_id
                         and previous.step.wait_for == step.wait_for)
            if not (read_only_plan and is_read(previous.step) and identical
                    and previous.mutation_epoch == mutation_epoch and previous.config_hash == config_hash):
                raise ValueError(
                    f"Step ID '{step.id}' already completed. It cannot identify another command, "
                    "replay a mutation, or reuse a read after changes. Return only remaining steps "
                    "with new unique IDs; refer to previous results through bindings."
                )
            failures = verify(results[step.id], step.expect)
            if failures:
                raise ValueError("Cached read does not satisfy the new checks: " + "; ".join(failures)
                                 + ". Use a new ID for an explicitly approved fresh read if needed.")
            reused.append(step.id)
        return plan.model_copy(update={"steps": pending}), reused

    async def run(self, request: str, plan_only: bool = False) -> Outcome:
        run_id = uuid.uuid4().hex[:12]
        self.task_inputs = {}
        update_task_inputs(self.task_inputs, request, self.settings.database_defaults)
        self.executor.task_inputs = self.task_inputs
        history: list[dict] = [{"task_defaults": self.task_inputs}]
        # Secret labels are local variables within a task, not persistent Vault secrets.
        self.executor.secret_values.clear()
        self.executor.vault_endpoints.clear()
        results: dict[str, Any] = {}
        completed: dict[str, CompletedStep] = {}
        mutation_epoch = 0
        verified = False
        changed = False
        self.audit.record(run_id, "received", {"request": request, "connection": self.settings.connection()})

        def finish(status: str, message: str) -> Outcome:
            safe = self.redactor.text(message)
            self.audit.record(run_id, status, {"message": safe})
            self.emit(f"\n{status.upper()} [{run_id}]: {safe}")
            return Outcome(run_id, status, safe)

        try:
            for stage_number in range(1, self.settings.max_stages + 1):
                self.emit(f"\nPlanning stage {stage_number} with {self.settings.model_name}...")
                plan = await self.planner.plan(request, history)
                self.audit.record(run_id, "planned", plan.model_dump())
                if plan.questions:
                    self.emit("\nThe agent needs this information:")
                    answers = []
                    for question in plan.questions:
                        answer = self.ask(self.redactor.text(question) + " ").strip()
                        if not answer:
                            return finish("blocked", "Required information was not supplied.")
                        answers.append({"question": question, "answer": self.redactor.text(answer)})
                        update_task_inputs(self.task_inputs, answer, self.settings.database_defaults)
                    history.append({"clarifications": answers})
                    continue
                if plan.phase == "complete":
                    if not verified:
                        return finish("blocked", "The model proposed completion without a passed verification stage.")
                    return finish("succeeded", plan.summary)
                if not plan.steps:
                    return finish("blocked", "No executable steps were proposed.")
                try:
                    await self._validate_plan(plan, results)
                    original_steps = plan.steps
                    plan, reused = self._reuse_completed_reads(plan, completed, results, mutation_epoch)
                except Exception as exc:
                    # No commands from this stage have run: feed validation/reference errors
                    # back to the planner, with the overall stage budget limiting revisions.
                    message = self.redactor.text(str(exc))
                    history.append({"unexecuted_plan": plan.model_dump(), "validation_error": message})
                    self.audit.record(run_id, "plan_rejected_locally", {"reason": message})
                    self.emit("Plan needs correction before execution: " + message[:1500])
                    continue
                if reused:
                    self.emit("Reusing completed read results: " + ", ".join(reused) + ". No repeated commands will run.")
                    reuse_event = {"reused_step_ids": reused,
                                   "remaining_step_ids": [step.id for step in plan.steps],
                                   "instruction": "These reads already succeeded in this run. Continue with remaining commands only. Return complete if verified evidence fully answers the request."}
                    history.append(reuse_event)
                    self.audit.record(run_id, "reused_reads", reuse_event)
                if not plan.steps:
                    verified = verified or all(bool(step.expect) for step in original_steps)
                    if plan_only:
                        return finish("planned", "All proposed commands reuse already completed reads; no commands executed.")
                    continue
                if plan_only:
                    self._show(plan, plan.digest(self.settings.connection()))
                    return finish("planned", "Plan displayed. No cloud resource commands were executed.")
                accepted, config_hash = self._approve(run_id, plan)
                if not accepted:
                    return finish("partially_completed" if changed else "cancelled", "Stage declined. No further commands were executed.")
                verified = False
                executed_steps: list[Step] = []
                for original in plan.steps:
                    step = original
                    repair_calls = 0
                    for attempt in range(self.settings.max_corrections + 1):
                        self._connection_unchanged(config_hash)
                        self.emit(f"Executing [{step.id}] {step.purpose} (attempt {attempt + 1})...")
                        self.audit.record(run_id, "executing", {"step": step.model_dump(), "attempt": attempt + 1})
                        result = await asyncio.to_thread(self.executor.execute, step, results)
                        public = result.public(self.redactor)
                        event = {"step": step.model_dump(), "result": public}
                        history.append(event)
                        self.audit.record(run_id, "response", event)
                        if result.code == 0:
                            if not is_read(step):
                                changed = True
                                mutation_epoch += 1
                            if step.wait_for:
                                polled = await wait_until_complete(
                                    self.executor, step, result, results, emit=self.emit,
                                    record=lambda kind, data: self.audit.record(run_id, kind, data),
                                    check_connection=lambda: self._connection_unchanged(config_hash))
                                history.append({"step_id": step.id, "completion": polled.message,
                                                "final_status": polled.result.public(self.redactor)})
                                self.audit.record(run_id, "poll_completed", {"step_id": step.id, "completed": polled.completed,
                                                                          "message": polled.message})
                                if not polled.completed:
                                    if polled.result.code == 0:
                                        self.emit(self.redactor.text(response_preview(polled.result)))
                                    return finish("partially_completed" if changed else "failed", polled.message)
                                result = polled.result
                            self.executor.resolve_expectations(step, results)
                            failures = verify(result.data, step.expect)
                            if is_read(step):
                                # Make successful read results visible even if a generated
                                # assertion is wrong; the CLI result is independent evidence.
                                self.emit(self.redactor.text(response_preview(result)))
                            if failures:
                                self.emit("\n".join(failures))
                                return finish("partially_completed" if changed else "failed", "The command returned, but verification failed. Review the recorded resource state before continuing.")
                            results[step.id] = result.data
                            self.executor.remember_response(status_step(step) if step.wait_for else step, result.data)
                            completed[step.id] = CompletedStep(step.model_copy(deep=True), mutation_epoch, config_hash)
                            executed_steps.append(step)
                            if step.wait_for:
                                executed_steps.append(status_step(step))
                            self.emit("  Command succeeded" + ("; checks passed." if step.expect else "."))
                            break
                        self.emit(f"  {result.category}: {self.redactor.text(error_preview(result))[:3000]}")
                        if result.category in {"permission", "local"}:
                            return finish("blocked", "Execution stopped: " + error_preview(result)[:4000])
                        if result.category == "uncertain" and not is_read(step):
                            return finish("blocked", "Mutation outcome is uncertain. Reconcile OCI work requests and resource state before retrying; this command was not resubmitted.")
                        if attempt == self.settings.max_corrections:
                            return finish("partially_completed" if changed else "failed", "Correction/retry budget exhausted.")
                        if result.category == "throttled" or (result.category == "uncertain" and is_read(step)):
                            await asyncio.sleep(min(2 ** attempt + random.random(), 10))
                            continue
                        self.emit("Consulting the reference to diagnose and correct the command...")
                        replacement = None
                        while repair_calls < self.settings.max_corrections:
                            repair_calls += 1
                            repair = await self.planner.repair(request, step, public, history)
                            if repair.questions or len(repair.steps) != 1:
                                return finish("blocked", repair.summary + " " + " ".join(repair.questions))
                            candidate = repair.steps[0]
                            try:
                                if candidate.id != step.id:
                                    raise ValueError("A correction changed the failed step ID; preserve its ID.")
                                await self._validate_plan(repair, results)
                                if candidate.command == step.command and candidate.arguments == step.arguments:
                                    raise ValueError("The correction repeats the same failed command. Correct the actual error without repeating it.")
                            except Exception as exc:
                                message = self.redactor.text(str(exc))
                                feedback = {"unexecuted_repair": repair.model_dump(), "repair_validation_error": message}
                                history.append(feedback)
                                self.audit.record(run_id, "repair_rejected_locally", feedback)
                                self.emit("Corrected plan needs further repair before execution: " + message[:1500])
                                public = dict(public, repair_validation_error=message)
                                continue
                            replacement = candidate
                            break
                        if replacement is None:
                            return finish("partially_completed" if changed else "failed", "No valid corrected command was produced within the repair budget. No invalid repair was executed.")
                        self.audit.record(run_id, "correction", repair.model_dump())
                        if not (result.category == "syntax" and automatic_syntax_repair(step, replacement) and step.expect == replacement.expect):
                            accepted, config_hash = self._approve(run_id, repair)
                            if not accepted:
                                return finish("partially_completed" if changed else "cancelled", "Corrected plan declined.")
                        else:
                            self.emit("Applying option spelling correction within the accepted plan.")
                        step = replacement
                # Checked reads AFTER the last actual change are verification even
                # when the model bundled create + get into one action stage.
                last_change = max((index for index, item in enumerate(executed_steps) if not is_read(item)), default=-1)
                verification_tail = executed_steps[last_change + 1:]
                verified = bool(verification_tail) and all(is_read(item) and item.expect for item in verification_tail)
                if changed and verified:
                    # Work-request success alone cannot establish resource readiness.
                    verified = any(not any("work-request" in word for word in item.command)
                                   for item in verification_tail)
                self.audit.record(run_id, "stage_completed", {"stage": stage_number, "phase": plan.phase})
            return finish("partially_completed" if changed else "blocked", "Stage budget reached. Inspect history before continuing with another task.")
        except (EOFError, KeyboardInterrupt):
            return finish("cancelled", "Interrupted. Previously submitted cloud operations may still be running; inspect OCI state before retrying.")
        except Exception as exc:
            diagnostics = getattr(exc, "diagnostics", None)
            if diagnostics:
                self.audit.record(run_id, "plan_format_failure", diagnostics)
            return finish("partially_completed" if changed else "failed", self.redactor.text(str(exc)))
