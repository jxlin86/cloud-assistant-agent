from __future__ import annotations

import argparse
import asyncio
import importlib.metadata
import os
from pathlib import Path

from . import __version__
from .audit import Audit, Redactor
from .config import load_settings
from .executor import Executor
from .workflow import Workflow
from .presentation import format_result


async def probe(settings, redactor: Redactor) -> int:
    from agents import Agent, OpenAIChatCompletionsModel, Runner, RunConfig, function_tool
    from .planner import build_client
    client = build_client(settings)
    called = False

    @function_tool
    def local_health_check() -> str:
        """Run a local connectivity test only; makes no OCI resource changes."""
        nonlocal called
        called = True
        return "READY"

    try:
        agent = Agent(
            name="OCI model connectivity check",
            instructions="Call local_health_check once, then reply READY. Do not do anything else.",
            model=OpenAIChatCompletionsModel(model=settings.model_name, openai_client=client),
            tools=[local_health_check],
        )
        result = await Runner.run(agent, "Check connectivity now.", max_turns=3,
                                  run_config=RunConfig(tracing_disabled=True, trace_include_sensitive_data=False))
        print("OCI inference: connected")
        print("Agents SDK tool calling: " + ("verified" if called else "NOT verified"))
        print("Response: " + redactor.text(str(result.final_output))[:500])
        return 0 if called else 2
    finally:
        await client.close()


async def run_agent(settings, args, redactor: Redactor, audit: Audit) -> int:
    from .planner import Planner
    executor = Executor(settings, redactor)
    planner = Planner(settings, executor, redactor)
    try:
        workflow = Workflow(settings, planner, executor, audit, redactor)
        print(f"OCI Operations agent v{__version__} | {settings.profile} | task region {settings.region}")
        print(f"Model: {settings.model_name} in {settings.model_region}. Type 'exit' to leave.")
        print("Read-only commands run automatically. Resource changes require ACCEPT.")
        print("Use {{secret:NAME}} in requests when a secret is needed; it will be collected locally.")
        while True:
            request = args.request or input("\nOCI task> ").strip()
            if request.lower() in {"exit", "quit"}:
                return 0
            if not request:
                continue
            outcome = await workflow.run(redactor.text(request), plan_only=args.plan_only)
            if args.request:
                return 0 if outcome.status in {"succeeded", "planned", "cancelled"} else 2
    finally:
        await planner.close()


def main() -> int:
    parser = argparse.ArgumentParser(description="Local OCI Operations agent using OCI-hosted gpt-oss")
    parser.add_argument("--config", type=Path, default=Path("agent.toml"))
    parser.add_argument("--profile", help="Select a named OCI config profile")
    parser.add_argument("--region", help="OCI command region, independent of model region")
    sub = parser.add_subparsers(dest="mode", required=True)
    sub.add_parser("profiles", help="List profile names and regions without credentials")
    doctor = sub.add_parser("doctor", help="Check local configuration without cloud commands")
    doctor.add_argument("--probe-model", action="store_true", help="Make a small OCI inference and local tool-call test")
    run = sub.add_parser("run", help="Start interactive tasks or run one request")
    run.add_argument("request", nargs="?")
    run.add_argument("--plan-only", action="store_true")
    sub.add_parser("history", help="Show recent sanitized execution events")
    args = parser.parse_args()
    redactor = Redactor()
    # A key from the environment is never included in model context or error output.
    if os.getenv("OCI_GENAI_API_KEY"):
        redactor.add(os.environ["OCI_GENAI_API_KEY"])
    try:
        settings = load_settings(args.config, args.profile, args.region)
        if args.mode == "profiles":
            print(format_result([{"name": name, "region": item["region"]} for name, item in settings.profiles().items()]))
            return 0
        if args.mode == "doctor":
            report = {
                "application_version": __version__,
                "connection": settings.connection(), "oci_config": str(settings.config_file),
                "oci_executable": settings.cli, "cli_exists": Path(settings.cli).is_file(),
                "model": settings.model_name, "model_region": settings.model_region,
                "model_endpoint": settings.base_url, "model_auth": settings.model_auth,
                "model_project_configured": bool(settings.model_project),
                "openai_agents_version": importlib.metadata.version("openai-agents"),
                "oci_genai_auth_version": importlib.metadata.version("oci-genai-auth"),
                "cloud_commands_executed": False,
                "command_timeout_seconds": settings.timeout,
                "completion_timeout_seconds": settings.wait_timeout,
                "poll_interval_seconds": settings.poll_interval,
            }
            print(format_result(report))
            if args.probe_model:
                return asyncio.run(probe(settings, redactor))
            return 0 if report["cli_exists"] else 2
        audit = Audit(settings.state_dir, redactor)
        if args.mode == "history":
            print(format_result(audit.recent()))
            return 0
        return asyncio.run(run_agent(settings, args, redactor, audit))
    except (KeyboardInterrupt, EOFError):
        print("Cancelled. Inspect OCI state before retrying any submitted mutation.")
        return 130
    except Exception as exc:
        print("Agent could not start: " + redactor.text(str(exc)))
        return 2
