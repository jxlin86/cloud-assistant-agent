"""Local non-secret defaults and validation for Autonomous Database creation."""
from __future__ import annotations

import re
import uuid

from .schema import Plan, Step


def generate_database_name() -> str:
    # Fourteen characters also fits older serverless limits; no punctuation.
    # Collision-resistant, not a guarantee of tenancy-wide uniqueness.
    return "FDE" + uuid.uuid4().hex[:11].upper()


def task_defaults(request: str, database_options: dict | None = None) -> dict:
    delegated = bool(re.search(
        r"(?:assign|generat\w*|choos\w*|pick|auto\w*|system).{0,70}(?:db.?name|database name)"
        r"|(?:db.?name|database name).{0,50}(?:system|auto\w*|generat\w*|you choose)", request, re.I))
    if not delegated and not (re.search(r"\bcreate\b|\bprovision\b|\bnew\b", request, re.I)
                              and re.search(r"database|\bATP\b|\bOLTP\b|\bAPEX\b", request, re.I)):
        return {}
    return {
        "database_name": generate_database_name(),
        "name_generation_delegated": delegated,
        "credential_input": "{{secret:ADMIN_PASSWORD}}",
        "credential_mode": "local_hidden_prompt",
        "vault_requested": bool(re.search(r"\bvault\b", request, re.I)),
        "requested_workload": "OLTP" if re.search(r"transaction(?:al)? processing|\bATP\b|\bOLTP\b", request, re.I) else None,
        "database_options": dict(database_options or {}),
    }


def option_value(arguments: list[str], flag: str) -> str | None:
    for index, value in enumerate(arguments):
        if value == flag:
            return arguments[index + 1] if index + 1 < len(arguments) else None
        if value.startswith(flag + "="):
            return value.split("=", 1)[1]
    return None


def update_task_inputs(inputs: dict, request: str, database_options: dict | None = None) -> None:
    """Merge clarification intent into the SAME context shared by every component."""
    for key, value in task_defaults(request, database_options).items():
        if key == "database_name":
            inputs.setdefault(key, value)
        elif key == "database_options":
            continue
        elif value is not None:
            inputs[key] = value
    options = dict(database_options or {})
    options.update(inputs.get("database_options", {}))
    if options:
        inputs["database_options"] = options


def initialize_database_step(step: Step, inputs: dict, database_options: dict | None = None) -> None:
    """Derive inputs from an actual create command, independent of request phrasing."""
    if step.command != ["db", "autonomous-database", "create"]:
        return
    update_task_inputs(inputs, "", database_options)
    name = option_value(step.arguments, "--db-name")
    if name and re.fullmatch(r"[A-Za-z][A-Za-z0-9]{0,29}", name):
        inputs["database_name"] = name  # Preserve the concrete command identity on repair.
    if not inputs.get("database_name"):
        inputs["database_name"] = generate_database_name()
    if not inputs.get("requested_workload"):
        workload = option_value(step.arguments, "--db-workload")
        inputs["requested_workload"] = workload if workload and "{{" not in workload else "OLTP"
    inputs.setdefault("credential_input", "{{secret:ADMIN_PASSWORD}}")
    inputs.setdefault("credential_mode", "local_hidden_prompt")


def validate_database_create_required(step: Step) -> None:
    if step.command != ["db", "autonomous-database", "create"] or option_value(step.arguments, "--from-json"):
        return
    if not any(option_value(step.arguments, flag) for flag in ("--data-storage-size-in-gbs", "--data-storage-size-in-tbs")):
        raise ValueError("Autonomous Database creation requires explicit storage in GBs or TBs. "
                         "Use configured database defaults or specify --data-storage-size-in-gbs/--data-storage-size-in-tbs; no create command was executed.")
    if not any(option_value(step.arguments, flag) for flag in ("--compute-count", "--cpu-core-count", "--ocpu-count")):
        raise ValueError("Autonomous Database creation requires explicit compute sizing. Configure database defaults or provide compute-count/cpu-core-count; no create command was executed.")
    if not option_value(step.arguments, "--db-name"):
        raise ValueError("Autonomous Database creation requires an internal database name.")


def prepare_database_create(step: Step, defaults: dict | None) -> None:
    if step.command != ["db", "autonomous-database", "create"] or option_value(step.arguments, "--from-json"):
        return
    defaults = defaults or {}
    name = option_value(step.arguments, "--db-name")
    if not name and defaults.get("database_name"):
        name = defaults["database_name"]
        step.arguments += ["--db-name", name]
    if name and "{{" not in name and not re.fullmatch(r"[A-Za-z][A-Za-z0-9]{0,29}", name):
        raise ValueError("Invalid --db-name: use 1-30 letters/numbers, starting with a letter, without hyphens. "
                         "The display name may contain hyphens. When generation is delegated, use task_defaults.database_name.")
    expected = defaults.get("requested_workload")
    workload = option_value(step.arguments, "--db-workload")
    if expected and workload and workload != expected:
        raise ValueError(f"The request requires --db-workload {expected}; do not create a different database workload.")
    if expected and not workload:
        step.arguments += ["--db-workload", expected]
    if not option_value(step.arguments, "--admin-password") and not option_value(step.arguments, "--secret-id"):
        step.arguments += ["--admin-password", "{{secret:ADMIN_PASSWORD}}"]
    secret_id = option_value(step.arguments, "--secret-id")
    if secret_id and option_value(step.arguments, "--admin-password"):
        raise ValueError("Use either a Vault --secret-id or a local --admin-password placeholder, not both.")
    if secret_id and not secret_id.startswith(("ocid1.", "{{steps.")):
        raise ValueError("--secret-id requires a real OCI Vault secret OCID, not a placeholder label. "
                         "Use --admin-password {{secret:ADMIN_PASSWORD}} for hidden local input.")
    if option_value(step.arguments, "--is-dedicated") != "true":
        flags = {"compute_model": "--compute-model", "compute_count": "--compute-count",
                 "data_storage_size_in_gbs": "--data-storage-size-in-gbs", "license_model": "--license-model",
                 "is_free_tier": "--is-free-tier", "is_auto_scaling_enabled": "--is-auto-scaling-enabled",
                 "is_auto_scaling_for_storage_enabled": "--is-auto-scaling-for-storage-enabled"}
        for key, value in defaults.get("database_options", {}).items():
            if key not in flags or option_value(step.arguments, flags[key]) is not None:
                continue
            if option_value(step.arguments, "--is-free-tier") == "true" and key in {"compute_model", "compute_count", "data_storage_size_in_gbs", "license_model"}:
                continue
            if key in {"compute_model", "compute_count"} and option_value(step.arguments, "--cpu-core-count") is not None:
                continue
            if key == "data_storage_size_in_gbs" and option_value(step.arguments, "--data-storage-size-in-tbs") is not None:
                continue
            step.arguments += [flags[key], str(value).lower() if isinstance(value, bool) else str(value)]


def validate_questions(plan: Plan, defaults: dict, history: list[dict] | None = None) -> None:
    if not defaults.get("database_name"):
        return
    for question in plan.questions:
        if re.search(r"already exists|exists in|existing database", question, re.I) and not any("result" in entry for entry in (history or [])):
            raise ValueError("No resource discovery result is available. Do not assert that a database exists. Return the read-only inventory stage first, then reason from its actual response.")
        if defaults.get("name_generation_delegated") and re.search(r"database name|db[- ]?name", question, re.I):
            raise ValueError("The user delegated database-name generation. Use task_defaults.database_name or generate_database_name; do not ask the user to supply it.")
        if not defaults.get("vault_requested") and re.search(r"admin.?password|password|secret name|name.{0,30}secret|secret.{0,30}name", question, re.I):
            raise ValueError("No Vault secret is required. Use --admin-password {{secret:ADMIN_PASSWORD}}; the executor asks for its VALUE in a hidden local prompt after acceptance. Do not ask for a password or secret alias in chat.")
