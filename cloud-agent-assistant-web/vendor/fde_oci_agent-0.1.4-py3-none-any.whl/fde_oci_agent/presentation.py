"""Deterministic terminal formatting; keep JSON internal to execution and audit."""
from __future__ import annotations

import re
import textwrap
from typing import Any


LABELS = {
    "display-name": "Name", "db-name": "Database", "lifecycle-state": "State",
    "db-workload": "Workload", "db-version": "Version", "id": "OCID",
    "compartment-id": "Compartment OCID", "home-region-key": "Home region",
    "data-storage-size-in-gbs": "Storage (GB)", "compute-count": "Compute",
    "run_id": "Run", "kind": "Event", "time": "Time",
}
PREFERRED = (
    "display-name", "name", "db-name", "lifecycle-state", "db-workload", "db-version",
    "region", "data-storage-size-in-gbs", "compute-count", "status", "type",
    "run_id", "event", "time", "id",
)


def label(key: str) -> str:
    return LABELS.get(key, key.replace("_", " ").replace("-", " ").capitalize())


def text(value: Any) -> str:
    if value is None:
        return "-"
    if isinstance(value, bool):
        return "Yes" if value else "No"
    if isinstance(value, dict):
        return f"{len(value)} fields" if value else "None"
    if isinstance(value, list):
        return ", ".join(text(v) for v in value) if all(not isinstance(v, (dict, list)) for v in value) else f"{len(value)} entries"
    # Resource names and returned text must not inject terminal escape sequences.
    return re.sub(r"[\x00-\x1f\x7f-\x9f]", " ", str(value)).strip()


def table(rows: list[dict], *, width: int = 120, max_rows: int = 100) -> str:
    if not rows:
        return "No resources found."
    keys = list(dict.fromkeys(key for row in rows for key in row))
    if not keys:
        return f"{len(rows)} empty record{'s' if len(rows) != 1 else ''} returned."
    preferred = [key for key in PREFERRED if key in keys]
    # One display-name column is sufficient; keep database names as a separate column.
    if "display-name" in preferred and "name" in preferred:
        preferred.remove("name")
    columns = preferred[:6] if len(preferred) >= 2 else keys[:6]
    # Leave long OCIDs in the details below when resources have useful names.
    if "id" in columns and len(columns) > 1 and any(key in columns for key in ("display-name", "name", "db-name")):
        columns.remove("id")
    # Prefer scalar columns to giant nested metadata in the main table.
    scalar = [key for key in columns if any(not isinstance(row.get(key), (dict, list)) for row in rows)]
    columns = scalar or columns
    shown = rows[:max_rows]
    def cell(row: dict, key: str) -> str:
        value = text(row.get(key))
        return value if len(value) <= 160 else value[:157] + "..."
    cap = max(12, min(32, (width - 3 * max(0, len(columns) - 1)) // max(1, len(columns))))
    sizes = [min(cap, max(len(label(key)), *(len(cell(row, key)) for row in shown))) for key in columns]
    lines = ["  ".join(label(key).ljust(size) for key, size in zip(columns, sizes)),
             "  ".join("-" * size for size in sizes)]
    for row in shown:
        cells = [textwrap.wrap(cell(row, key), size, break_long_words=True, break_on_hyphens=False) or [""]
                 for key, size in zip(columns, sizes)]
        for index in range(max(len(cell) for cell in cells)):
            lines.append("  ".join((cell[index] if index < len(cell) else "").ljust(size)
                                   for cell, size in zip(cells, sizes)).rstrip())
    lines.append(f"\n{len(rows)} result{'s' if len(rows) != 1 else ''}.")
    if len(rows) > max_rows:
        lines.append(f"Showing the first {max_rows}; remaining records are in local history.")
    if "id" not in columns:
        identities = [row for row in shown if row.get("id")]
        if identities:
            lines.append("\nResource identifiers:")
            for row in identities:
                name = row.get("display-name") or row.get("name") or row.get("db-name") or "Resource"
                lines.append(f"  {text(name)}: {text(row['id'])}")
    return "\n".join(lines)


def _details(data: dict, depth: int = 0) -> list[str]:
    lines = []
    priority = [key for key in PREFERRED if key in data]
    keys = priority + [key for key in data if key not in priority]
    for key in keys:
        value = data[key]
        if value is None:
            continue
        prefix = "  " * depth + label(key)
        if isinstance(value, dict) and value and depth < 2:
            lines.append(prefix + ":")
            lines.extend(_details(value, depth + 1))
        elif isinstance(value, list) and value and all(isinstance(item, dict) for item in value) and depth < 2:
            lines.append(prefix + ":")
            lines.extend("  " * (depth + 1) + line for line in table(value).splitlines())
        else:
            lines.append(prefix + ": " + text(value))
    return lines or ["No fields returned."]


def format_result(payload: Any) -> str:
    data = payload.get("data") if isinstance(payload, dict) and "data" in payload else payload
    if isinstance(data, dict) and isinstance(data.get("items"), list):
        data = data["items"]
    if isinstance(data, list):
        if not data:
            return "No resources found."
        if all(isinstance(item, dict) for item in data):
            return table(data)
        return "\n".join(f"  {index}. {text(item)}" for index, item in enumerate(data, 1)) + f"\n\n{len(data)} results."
    if isinstance(data, dict):
        return "\n".join(_details(data))
    return "No data returned." if data is None else text(data)
