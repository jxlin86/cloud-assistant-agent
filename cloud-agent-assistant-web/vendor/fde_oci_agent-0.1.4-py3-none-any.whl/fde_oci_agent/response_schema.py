"""Read response metadata from installed OCI SDK models; never call OCI APIs."""
from __future__ import annotations

import importlib
import inspect
import re
from functools import lru_cache

from .schema import Expectation, Step, path_parts
from .executor import canonical_command


# Conservative aliases for CLI commands with known SDK service modules.
# Unknown services/commands remain available; their assertions are checked at runtime.
SERVICE_MODULES = {
    "iam": "identity", "db": "database", "devops": "devops",
    "compute": "core", "network": "core", "bv": "core", "os": "object_storage",
    "ons": "ons", "logging": "logging", "audit": "audit",
    "generative-ai": "generative_ai", "generative-ai-inference": "generative_ai_inference",
    "kms": "key_management", "vault": "vault",
}


def _model_fields(model_path: str) -> dict[str, str]:
    module_name, class_name = model_path.rsplit(".", 1)
    cls = getattr(importlib.import_module(module_name), class_name)
    return {key.replace("_", "-"): value for key, value in cls().swagger_types.items()}


def response_schema(command: list[str]) -> dict:
    return _response_schema(tuple(canonical_command(command)))


@lru_cache(maxsize=128)
def _response_schema(command: tuple[str, ...]) -> dict:
    supported_path = len(command) == 3 or (len(command) == 4 and command[:2] == ("kms", "management"))
    if not supported_path or command[-1] not in {"get", "list"} or command[0] not in SERVICE_MODULES:
        return {"known": False, "reason": "No verified model mapping for this command; use reference and runtime response."}
    service = f"oci.{SERVICE_MODULES[command[0]]}"
    resource = command[-2].replace("-", "_")
    resource = {("db", "system"): "db_system"}.get((command[0], command[1]), resource)
    plural = resource[:-1] + "ies" if resource.endswith("y") and not resource.endswith(("ay", "ey", "oy")) else resource + "s"
    operation = ("get_" + resource) if command[-1] == "get" else ("list_" + plural)
    try:
        module = importlib.import_module(service)
        for name in dir(module):
            if not name.endswith("Client"):
                continue
            method = getattr(getattr(module, name), operation, None)
            if method is None:
                continue
            doc = inspect.getdoc(method) or ""
            match = re.search(r":return:.*?data of type (list of )?:class:`~(oci\.[\w.]+)`", doc)
            if not match:
                continue
            array = bool(match.group(1))
            model_path = match.group(2)
            model_fields = _model_fields(model_path)
            fields = {} if array else model_fields
            items_path = "data" if array else ("data.items" if "items" in fields else None)
            return {
                "known": True, "model": model_path, "operation": operation,
                "source": "installed OCI Python SDK operation return type (local metadata; no API call)",
                "root": "data", "data_type": "array" if array else "object",
                "items_path": items_path, "fields": fields,
                "item_fields": model_fields if array else {},
            }
    except (ImportError, AttributeError, TypeError):
        pass
    return {"known": False, "reason": "No matching installed SDK operation response metadata; inspect the reference and actual response."}


def validate_expectation_fields(step: Step) -> None:
    # Query projections and full JSON inputs can alter response shape/command inputs.
    if any(arg.split("=", 1)[0] in {"--query", "--from-json"} for arg in step.arguments):
        return
    metadata = response_schema(step.command)
    if not metadata["known"]:
        return
    fields = metadata["fields"]
    for expectation in step.expect:
        parts = path_parts(expectation.path)
        if metadata["data_type"] == "array" and len(parts) >= 2 and parts[0] == "data":
            if not parts[1].isdigit():
                raise ValueError(
                    f"Unsupported response path '{expectation.path}': {metadata['operation']} returns "
                    "an array directly under data, not data.items. Use data for list checks "
                    "or numeric indices such as data.0.id. Correct the plan before execution."
                )
            if len(parts) >= 3 and parts[2] not in metadata["item_fields"]:
                raise ValueError(f"Unsupported list-item field '{expectation.path}' for {metadata['model']}.")
            continue
        if len(parts) >= 2 and parts[0] == "data" and parts[1] not in fields:
            raise ValueError(
                f"Unsupported response field '{expectation.path}' for {metadata['model']}. "
                f"Documented data fields: {', '.join(sorted(fields))}. "
                "Correct the plan before execution; do not invent resource fields."
            )


def add_list_shape_check(step: Step) -> None:
    """Keep empty inventories valid and ground list checks in the SDK return shape."""
    if step.command[-1] != "list" or any(arg.split("=", 1)[0] in {"--query", "--from-json"} for arg in step.arguments):
        return
    metadata = response_schema(step.command)
    path = metadata.get("items_path") if metadata["known"] else None
    if path and not any(e.path == path for e in step.expect):
        step.expect.append(Expectation(path=path, operator="exists"))


def add_read_identity_check(step: Step) -> None:
    """Ground a known resource get in its requested OCID, even if the LLM omits checks."""
    if any(arg.split("=", 1)[0] in {"--query", "--from-json"} for arg in step.arguments):
        return
    metadata = response_schema(step.command)
    if step.command[-1] != "get" or not metadata["known"] or "id" not in metadata["fields"]:
        return
    flag = f"--{step.command[-2]}-id"
    for index, argument in enumerate(step.arguments):
        if argument == flag and index + 1 < len(step.arguments):
            value = step.arguments[index + 1]
        elif argument.startswith(flag + "="):
            value = argument.split("=", 1)[1]
        else:
            continue
        if value.startswith("ocid1.") and not any(e.path == "data.id" and e.operator == "equals" and e.value == value for e in step.expect):
            step.expect.append(Expectation(path="data.id", operator="equals", value=value))
        return
