from __future__ import annotations

import configparser
import os
import shutil
import tomllib
from dataclasses import dataclass, field
from pathlib import Path


@dataclass(frozen=True)
class Settings:
    root: Path
    config_file: Path
    profile: str
    region: str
    compartment_id: str
    model_name: str
    model_region: str
    model_project: str
    model_auth: str
    cli: str
    timeout: int = 180
    max_corrections: int = 3
    max_stages: int = 8
    max_steps: int = 12
    max_turns: int = 16
    state_name: str = ".fde-agent"
    database_defaults: dict = field(default_factory=dict)
    wait_timeout: int = 3600
    poll_interval: int = 15

    @property
    def state_dir(self) -> Path:
        return self.root / self.state_name

    @property
    def base_url(self) -> str:
        return f"https://inference.generativeai.{self.model_region}.oci.oraclecloud.com/openai/v1"

    def profiles(self) -> dict[str, dict[str, str]]:
        parser = configparser.ConfigParser(interpolation=None)
        if not parser.read(self.config_file, encoding="utf-8-sig"):
            raise ValueError(f"OCI config not found: {self.config_file}")
        names = (["DEFAULT"] if parser.defaults() else []) + parser.sections()
        return {
            name: {key: parser[name].get(key, "") for key in ("region", "tenancy")}
            for name in names
        }

    def profile_uses_session(self) -> bool:
        parser = configparser.ConfigParser(interpolation=None)
        parser.read(self.config_file, encoding="utf-8-sig")
        return bool(parser[self.profile].get("security_token_file"))

    def connection(self) -> dict[str, str]:
        metadata = self.profiles()
        if self.profile not in metadata:
            raise ValueError(f"OCI profile '{self.profile}' was not found.")
        return {
            "profile": self.profile,
            "region": self.region,
            "tenancy": metadata[self.profile]["tenancy"],
            "default_compartment": self.compartment_id,
        }


def load_settings(path: Path, profile: str | None = None, region: str | None = None) -> Settings:
    path = path.resolve()
    data = tomllib.loads(path.read_text(encoding="utf-8-sig"))
    cloud, model, execution = data["oci"], data["model"], data.get("execution", {})
    cli = shutil.which("oci") or str(Path.home() / "bin" / "oci.exe")
    settings = Settings(
        root=path.parent,
        config_file=Path(cloud["config_file"]).expanduser().resolve(),
        profile=profile or cloud["profile"],
        region=region or cloud["region"],
        compartment_id=cloud.get("compartment_id", ""),
        model_name=os.getenv("FDE_MODEL", model["name"]),
        model_region=os.getenv("FDE_MODEL_REGION", model["region"]),
        model_project=os.getenv("OCI_GENAI_PROJECT_ID", model.get("project_id", "")),
        model_auth=model.get("auth", "profile"),
        cli=cli,
        timeout=int(execution.get("timeout_seconds", 180)),
        wait_timeout=int(execution.get("wait_timeout_seconds", 3600)),
        poll_interval=int(execution.get("poll_interval_seconds", 15)),
        max_corrections=int(execution.get("max_corrections", 3)),
        max_stages=int(execution.get("max_stages", 8)),
        max_steps=int(execution.get("max_steps_per_stage", 12)),
        max_turns=int(execution.get("max_model_turns", 16)),
        state_name=execution.get("state_dir", ".fde-agent"),
        database_defaults=dict(data.get("database_defaults", {})),
    )
    import re
    if not re.fullmatch(r"[a-z0-9-]+", settings.model_region):
        raise ValueError("Invalid model region.")
    if settings.model_auth not in {"profile", "api_key"}:
        raise ValueError("model.auth must be profile or api_key.")
    if min(settings.timeout, settings.max_stages, settings.max_steps, settings.max_turns) < 1:
        raise ValueError("Execution budgets must be positive.")
    if not 0 <= settings.max_corrections <= 10:
        raise ValueError("max_corrections must be between 0 and 10.")
    if not 1 <= settings.poll_interval <= 60 or not 1 <= settings.wait_timeout <= 86400:
        raise ValueError("poll_interval_seconds must be 1-60 and wait_timeout_seconds must be 1-86400.")
    settings.connection()
    return settings
