"""Bounded, read-only resource/work-request polling after one submission."""
from __future__ import annotations

import asyncio
import copy
import subprocess
import time
from dataclasses import dataclass, replace
from typing import Any

from .executor import CommandResult, Executor, error_preview, requires_approval, is_read
from .schema import Expectation, Step, WaitFor, at_path, path_parts


# Verified resource GET endpoints; other services use an explicit wait_for plan.
CREATE_READS = {
    ("kms", "management", "vault", "create"): ("--vault-id", "ACTIVE"),
    ("db", "autonomous-database", "create"): ("--autonomous-database-id", "AVAILABLE"),
    ("kms", "management", "key", "create"): ("--key-id", "ENABLED"),
}
NATIVE_WAIT_FLAGS = {"--wait-for-state", "--max-wait-seconds", "--wait-interval-seconds"}
READY_STATES = {"ACTIVE", "AVAILABLE", "RUNNING", "STOPPED", "SUCCEEDED", "READY", "ENABLED", "DISABLED", "INACTIVE", "TERMINATED", "DELETED"}


def prepare_wait(step: Step) -> None:
    # A later verification GET is also a completion monitor, across services.
    # Informational GETs without an explicit desired state remain ordinary reads.
    if step.wait_for is None and step.command[-1] == "get" and not any(
        arg.split("=", 1)[0] in {"--query", "--from-json"} for arg in step.arguments
    ):
        target = next((check for check in step.expect if check.path in {"data.lifecycle-state", "data.status"}
                       and check.operator == "equals" and isinstance(check.value, str)
                       and check.value in READY_STATES), None)
        if target:
            step.wait_for = WaitFor(command=list(step.command), arguments=list(step.arguments),
                                    state_path=target.path, success_states=[target.value])
    default = CREATE_READS.get(tuple(step.command))
    if default and step.wait_for is None:
        flag, state = default
        step.wait_for = WaitFor(command=[*step.command[:-1], "get"],
                                arguments=[flag, "{{steps." + step.id + ".data.id}}"],
                                success_states=[state],
                                failure_states=["FAILED", "FAULTY", "ERROR", "TERMINATED", "DELETED",
                                                "PENDING_DELETION", "SCHEDULING_DELETION"])
        if step.command[:3] == ["kms", "management", "key"]:
            step.wait_for.failure_states.append("DISABLED")
    if step.wait_for is None:
        return
    # Strip blocking CLI waiter flags BEFORE approval; our read loop owns waiting.
    arguments, index = [], 0
    while index < len(step.arguments):
        arg = step.arguments[index]
        if arg.split("=", 1)[0] in NATIVE_WAIT_FLAGS:
            if "=" not in arg:
                if index + 1 >= len(step.arguments):
                    raise ValueError(f"{arg} requires a value.")
                index += 1
        else:
            arguments.append(arg)
        index += 1
    step.arguments = arguments
    if not step.expect:
        step.expect.append(Expectation(path=step.wait_for.state_path, operator="exists"))
    if any(arg.split("=", 1)[0] in {"--query", "--from-json"} for arg in arguments):
        raise ValueError("A polled submission must retain the complete JSON response; remove --query/--from-json.")


def status_step(step: Step) -> Step:
    wait = step.wait_for
    assert wait is not None
    path_parts(wait.state_path)
    if set(wait.success_states) & set(wait.failure_states):
        raise ValueError("Polling success and failure states must be disjoint.")
    if any(not value.strip() for value in [*wait.success_states, *wait.failure_states]):
        raise ValueError("Polling states cannot be empty.")
    poll = Step(id=step.id, purpose=f"Check completion of {step.id}",
                command=wait.command, arguments=list(wait.arguments),
                vault_id=step.vault_id if wait.command[:3] == ["kms", "management", "key"] else None,
                expect=[Expectation(path=wait.state_path, operator="exists")])
    if requires_approval(poll) or poll.command[-1] != "get":
        raise ValueError("Polling must use a read-only get without local file effects.")
    if any(arg.split("=", 1)[0] in {"--query", "--from-json", *NATIVE_WAIT_FLAGS} for arg in poll.arguments):
        raise ValueError("Polling GET must return the complete resource JSON without a CLI waiter.")
    if any("{{secret:" in arg for arg in poll.arguments):
        raise ValueError("Status checks cannot require secret input.")
    return poll


@dataclass
class PollResult:
    result: CommandResult
    completed: bool
    message: str


async def wait_until_complete(executor: Executor, step: Step, submitted: CommandResult,
                              results: dict[str, Any], *, emit, record, check_connection,
                              clock=time.monotonic, sleep=asyncio.sleep) -> PollResult:
    """Never retry the mutation. Keep its response available for status bindings."""
    wait = step.wait_for
    assert wait is not None
    poll = status_step(step)
    executor.resolve_metadata(poll)
    executor.validate(poll)
    bindings = {**results, step.id: submitted.data}
    # Freeze selectors against the submission before the first poll.
    poll.arguments = [executor._resolve(arg, bindings) for arg in poll.arguments]
    executor.validate(poll, resolved=True)
    start = clock()
    deadline = start + executor.settings.wait_timeout
    last = submitted
    initial_read = (is_read(step) and poll.command == step.command
                    and poll.arguments == [executor._resolve(arg, results) for arg in step.arguments])
    emit(f"Waiting for {step.id}: {', '.join(wait.success_states)}; checking every {executor.settings.poll_interval}s, up to {executor.settings.wait_timeout}s.")
    emit("  Monitoring: " + executor.redactor.text(subprocess.list2cmdline(["oci", *poll.command, *poll.arguments])))
    while clock() < deadline:
        check_connection()
        # Bound each GET by the remaining overall budget, independently of create.
        if initial_read:
            initial_read = False
        else:
            reader = copy.copy(executor)
            reader.settings = replace(executor.settings, timeout=max(1, min(executor.settings.timeout, int(deadline - clock()))))
            last = await asyncio.to_thread(reader.execute, poll, bindings)
        record("poll_response", {"step_id": step.id, "poll": poll.model_dump(),
                                 "elapsed_seconds": int(clock() - start), "result": last.public(executor.redactor)})
        if last.code:
            if last.category not in {"uncertain", "throttled"}:
                return PollResult(last, False, "Status check failed: " + error_preview(last))
            emit(f"  [{step.id}] Status read temporarily unavailable; retrying the GET only.")
        else:
            try:
                state = at_path(last.data, wait.state_path)
            except (KeyError, IndexError, TypeError, ValueError):
                return PollResult(last, False, f"Status response has no {wait.state_path}; cannot confirm completion.")
            emit(f"  [{step.id}] {state} ({int(clock() - start)}s elapsed)")
            if state in wait.failure_states:
                return PollResult(last, False, f"Resource reached terminal failure state {state}. The action was not resubmitted.")
            if state in wait.success_states:
                return PollResult(last, True, f"Resource reached {state}.")
            if not isinstance(state, str) or not state:
                return PollResult(last, False, "Status response did not contain a usable state.")
        remaining = deadline - clock()
        if remaining > 0:
            await sleep(min(executor.settings.poll_interval, remaining))
    return PollResult(last, False, f"Completion timeout after {executor.settings.wait_timeout}s. The resource may still be provisioning. Inspect its status before retrying; the action was not resubmitted.")
