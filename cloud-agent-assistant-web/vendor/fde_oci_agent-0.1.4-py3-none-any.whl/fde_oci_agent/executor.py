from __future__ import annotations

import getpass
import json
import os
import re
import subprocess
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable

import jmespath

from .audit import Redactor
from .config import Settings
from .schema import Step, at_path, path_parts
from .presentation import format_result
from .kms import is_key_command, management_endpoint, prepare_key


COMMAND_WORD = re.compile(r"^[a-z][a-z0-9-]*$")
PLACEHOLDER = re.compile(r"\{\{(steps\.[a-z][a-z0-9_]*\.[^{}]+|secret:[A-Z][A-Z0-9_]*|connection\.(?:profile|region|tenancy|default_compartment)|task_defaults\.(?:database_name|requested_workload|credential_input|database_options\.(?:compute_model|compute_count|data_storage_size_in_gbs|license_model|is_free_tier|is_auto_scaling_enabled|is_auto_scaling_for_storage_enabled)))\}\}")
MANAGED_FLAGS = {
    "--profile", "--config-file", "--region", "--auth", "--endpoint", "--proxy",
    "--cli-rc-file", "--defaults-file", "--debug", "--output", "--no-retry",
    "--max-retries", "--cli-auto-prompt", "--cert-bundle", "--auth-purpose",
    "--federation-endpoint", "--realm-specific-endpoint", "--enable-dual-stack",
    "--generate-full-command-json-input", "--generate-param-json-input",
    "--help", "-?", "--version", "--latest-version", "--release-info",
    "--raw-output",
}
READ_ACTIONS = {"get", "list", "head", "describe", "lookup", "summarize", "search", "get-status", "list-commits", "list-refs"}


def canonical_command(command: list[str]) -> list[str]:
    """Translate evidenced SDK/service spelling to the canonical OCI CLI service."""
    if command and (command[0] == "database" or command[:2] == ["adb", "autonomous-database"]):
        return ["db", *command[1:]]
    return list(command)


@dataclass
class CommandResult:
    code: int
    data: Any
    stdout: str
    stderr: str
    category: str
    output_note: str | None = None

    def public(self, redactor: Redactor) -> dict:
        # Keep full sanitized data locally for bindings, cap text sent to the model.
        return redactor.clean({
            "exit_code": self.code, "category": self.category,
            "response": self.data if len(json.dumps(self.data)) < 24000 else "Response too large; use a narrower query.",
            "stdout": "" if self.data is not None else self.stdout[:16000],
            "stderr": error_preview(self)[:8000] if self.code else self.stderr[:8000],
            "service_error": service_error_details(self) or None,
            "output_note": self.output_note,
        })


def service_error_details(result: CommandResult) -> dict:
    for output in (result.stderr, result.stdout):
        for match in list(re.finditer(r"\{", output))[:30]:
            try:
                data, _ = json.JSONDecoder().raw_decode(output, match.start())
            except ValueError:
                continue
            if isinstance(data, dict) and "code" in data and "message" in data:
                return {key: data[key] for key in ("code", "message", "status", "opc-request-id", "operation_name", "target_service") if key in data}
    return {}


def error_preview(result: CommandResult) -> str:
    error = service_error_details(result)
    if not error:
        return result.stderr or result.stdout
    status = f" (HTTP {error['status']})" if error.get("status") else ""
    message = f"OCI {error['code']}{status}: {error['message']}"
    if error.get("opc-request-id"):
        message += "\nRequest ID: " + str(error["opc-request-id"])
    return message


def classify(code: int, stdout: str, stderr: str) -> str:
    if code == 0:
        return "success"
    text = (stdout + "\n" + stderr).lower()
    if code == 124:
        return "uncertain"
    if any(s in text for s in ("maximum wait time", "max wait time", "wait time exceeded", "waiter timed out")):
        return "uncertain"
    if any(s in text for s in ("notauthorizedornotfound", "notauthorized", "notauthenticated", "authorization failed", "permission denied", "citizen role", "rejected", "invalidsecuritytoken", "expired token")):
        return "permission"
    if any(s in text for s in ("no such option", "missing option", "invalid value", "invalid json", "no such command", "unexpected extra argument")):
        return "syntax"
    if any(s in text for s in ("toomanyrequests", "throttl", "status: 429", '"status": 429')):
        return "throttled"
    if any(s in text for s in ("timed out", "connection reset", "connection aborted", "serviceunavailable", "internalservererror", "readtimeout", "connecttimeout")):
        return "uncertain"
    return "service"


def response_preview(result: CommandResult) -> str:
    """Present sanitized structured results as readable tables or labelled details."""
    if result.data is not None:
        return format_result(result.data)
    if result.stdout.strip() == "null":
        return "The response is null; it does not establish that a resource list is empty."
    if len(result.stdout) <= 8000:
        return result.stdout
    return result.stdout[:8000] + "\n[Display shortened; full sanitized response is available in local history.]"


def is_read(step: Step) -> bool:
    return step.command[-1] in READ_ACTIONS or tuple(step.command) in {
        ("search", "resource", "structured-search"), ("logging-search", "search-logs"),
    }


def requires_approval(step: Step) -> bool:
    if not is_read(step):
        return True
    # Cloud reads that write local files or hide options in a file remain explicit.
    local_effect_flags = {"--file", "--output-file", "--destination-file", "--force", "--from-json"}
    return any(argument.split("=", 1)[0] in local_effect_flags for argument in step.arguments)


def automatic_syntax_repair(old: Step, new: Step) -> bool:
    """Only option spelling changes with identical positional values are automatic."""
    if (old.command != new.command or len(old.arguments) != len(new.arguments)
            or old.vault_id != new.vault_id or old.wait_for != new.wait_for):
        return False
    changed = False
    for before, after in zip(old.arguments, new.arguments):
        if before == after:
            continue
        if not (before.startswith("--") and after.startswith("--")):
            return False
        # Target selectors, local paths, connection, and destructive switches need review.
        if any(word in before + after for word in ("-id", "file", "force", "delete", "preserve", "retain", "auth", "profile", "region", "endpoint")):
            return False
        changed = True
    return changed


class Executor:
    def __init__(self, settings: Settings, redactor: Redactor, secret_prompt: Callable[[str], str] = getpass.getpass):
        self.settings, self.redactor = settings, redactor
        self.secret_prompt = secret_prompt
        self.secret_values: dict[str, str] = {}
        self.task_inputs: dict = {}
        self.vault_endpoints: dict[str, str] = {}
        self.files_dir = settings.state_dir / "files"
        self.files_dir.mkdir(parents=True, exist_ok=True)
        self.empty_rc = settings.state_dir / "empty-oci-cli-rc"
        self.empty_rc.write_text("", encoding="utf-8")

    def resolve_metadata(self, step: Step) -> None:
        """Expand non-secret server values before displaying a change plan."""
        def replace(match: re.Match) -> str:
            key = match.group(1)
            if key.startswith("connection."):
                return str(self.settings.connection()[key.split(".", 1)[1]])
            if key.startswith("task_defaults."):
                try:
                    value = at_path(self.task_inputs, key.split(".", 1)[1])
                except (KeyError, TypeError) as exc:
                    raise ValueError(f"No task value is available for {key}. Use an actual configured value.") from exc
                if value is None:
                    raise ValueError(f"Task value {key} is not set.")
                return str(value).lower() if isinstance(value, bool) else str(value)
            return match.group(0)  # Step bindings and secret values are resolved later.
        def expand(value: Any, typed: bool = False) -> Any:
            if isinstance(value, str):
                match = PLACEHOLDER.fullmatch(value)
                if typed and match and match.group(1).startswith("task_defaults."):
                    return at_path(self.task_inputs, match.group(1).split(".", 1)[1])
                return PLACEHOLDER.sub(replace, value)
            if isinstance(value, list):
                return [expand(item, typed) for item in value]
            if isinstance(value, dict):
                return {key: expand(item, typed) for key, item in value.items()}
            return value
        step.arguments = expand(step.arguments)
        if step.vault_id is not None:
            step.vault_id = expand(step.vault_id)
        for check in step.expect:
            check.value = expand(check.value, typed=True)

    def resolve_expectations(self, step: Step, results: dict[str, Any]) -> None:
        """Resolve previous-step expected values without collecting any credentials."""
        def resolve(value: Any) -> Any:
            if isinstance(value, str):
                matches = list(PLACEHOLDER.finditer(value))
                if any(match.group(1).startswith("secret:") for match in matches):
                    raise ValueError("Secret values cannot be used as verification expectations.")
                whole = PLACEHOLDER.fullmatch(value)
                if whole and whole.group(1).startswith("steps."):
                    _, step_id, field = whole.group(1).split(".", 2)
                    return self._step_value(results, step_id, field)
                return self._resolve(value, results) if matches else value
            if isinstance(value, list):
                return [resolve(item) for item in value]
            if isinstance(value, dict):
                return {key: resolve(item) for key, item in value.items()}
            return value
        for check in step.expect:
            check.value = resolve(check.value)

    def validate(self, step: Step, resolved: bool = False) -> None:
        step.command = canonical_command(step.command)
        if not all(COMMAND_WORD.fullmatch(word) for word in step.command):
            raise ValueError("Command path must contain only OCI subcommand names, without 'oci'.")
        if step.command[0] in {"raw-request", "setup", "session"}:
            raise ValueError("Raw HTTP, CLI installation/configuration, and interactive login require a separate local operator action in v0.1.")
        if step.vault_id is not None and "{{secret:" in step.vault_id:
            raise ValueError("Vault context must be a non-secret Vault OCID.")
        for check in step.expect:
            path_parts(check.path)
            if "{{secret:" in str(check.value):
                raise ValueError("Verification cannot require a secret value; verify public resource fields instead.")
        if sum(argument == "--query" or argument.startswith("--query=") for argument in step.arguments) > 1:
            raise ValueError("Use exactly one --query expression per command.")
        for argument in step.arguments:
            if "\x00" in argument or "\n" in argument or "\r" in argument:
                raise ValueError("Command arguments cannot contain NUL or literal newlines; encode JSON newlines.")
            remaining = PLACEHOLDER.sub("", argument)
            if "{{" in remaining or "}}" in remaining:
                raise ValueError("Unsupported placeholder. Use actual task-default values, {{steps.step_id.data.id}}, {{connection.default_compartment}}, or {{secret:NAME}}.")
            flag = argument.split("=", 1)[0]
            if flag in MANAGED_FLAGS:
                raise ValueError(f"Connection/output/help option is managed by the executor: {flag}")
            if argument.startswith("-") and not argument.startswith("--"):
                # Reject short aliases for managed globals as well as ambiguous combined flags.
                raise ValueError("Use documented long option names; negative numbers must be passed with --option=-1 syntax.")
            if argument.startswith("file://"):
                if not resolved and "{{" in argument:
                    continue
                self._check_file(argument[7:])
        for index, argument in enumerate(step.arguments):
            flag = argument.split("=", 1)[0]
            # File input/output must stay in the explicitly displayed task file directory.
            if flag in {"--file", "--output-file", "--destination-file", "--source-file", "--private-key-file", "--public-key-file", "--ssh-key-file", "--content-file"}:
                value = argument.split("=", 1)[1] if "=" in argument else step.arguments[index + 1] if index + 1 < len(step.arguments) else ""
                if not resolved and "{{" in value:
                    continue
                self._check_file(value)
        for index, argument in enumerate(step.arguments):
            if argument.startswith("--") and re.search(r"password|pass-phrase|secret|token|key-content", argument.split("=", 1)[0], re.I):
                flag = argument.split("=", 1)[0]
                # Resource identifiers such as secret-id and retry tokens are not passwords.
                if flag.endswith("-id") or flag in {"--opc-retry-token", "--page"}:
                    continue
                value = argument.split("=", 1)[1] if "=" in argument else step.arguments[index + 1] if index + 1 < len(step.arguments) else ""
                if not resolved and not re.fullmatch(r"\{\{secret:[A-Z][A-Z0-9_]*\}\}", value):
                    raise ValueError(f"Use a local secret placeholder for {flag}, e.g. {{{{secret:ADMIN_PASSWORD}}}}.")

    def _check_file(self, filename: str) -> None:
        path = Path(filename).expanduser()
        if not path.is_absolute():
            path = self.settings.root / path
        if not path.resolve().is_relative_to(self.files_dir.resolve()):
            raise ValueError(f"Task file access is limited to {self.files_dir}; copy approved inputs there first.")

    def _resolve(self, argument: str, results: dict[str, Any]) -> str:
        def replace(match: re.Match) -> str:
            key = match.group(1)
            if key.startswith("connection."):
                return str(self.settings.connection()[key.split(".", 1)[1]])
            if key == "task_defaults.database_name":
                return str(self.task_inputs["database_name"])
            if key.startswith("secret:"):
                name = key.split(":", 1)[1]
                if name not in self.secret_values:
                    prompt = "Enter the database ADMIN password (hidden, stays on this laptop): " if name == "ADMIN_PASSWORD" else f"Enter the value for {name} (hidden): "
                    value = self.secret_prompt(prompt)
                    if not value:
                        raise ValueError("A required local secret was empty.")
                    self.secret_values[name] = value
                    self.redactor.add(value)
                return self.secret_values[name]
            _, step_id, field = key.split(".", 2)
            value = self._step_value(results, step_id, field)
            if isinstance(value, (dict, list)):
                return json.dumps(value, separators=(",", ":"))
            if value is None:
                raise ValueError(f"Binding {key} is null.")
            return str(value)
        result = PLACEHOLDER.sub(replace, argument)
        if "{{" in result or "}}" in result:
            raise ValueError("Unresolved or unsupported command placeholder.")
        return result

    def _step_value(self, results: dict[str, Any], step_id: str, field: str) -> Any:
        if step_id not in results:
            raise ValueError(f"Binding source step {step_id!r} has no completed result.")
        try:
            return at_path(results[step_id], field)
        except (KeyError, IndexError, TypeError, ValueError) as exc:
            value = results[step_id]
            shape = ("object with root keys " + ", ".join(map(str, list(value)[:12]))) if isinstance(value, dict) else type(value).__name__
            raise ValueError(f"Invalid binding steps.{step_id}.{field}: source result is {shape}. "
                             f"Use {{{{steps.{step_id}.$}}}} for the entire projected root; do not add a data wrapper to a scalar or projected list.") from exc

    def validate_bindings(self, step: Step, results: dict[str, Any], pending: set[str]) -> None:
        """Validate known response paths before approval without prompting for secrets."""
        def check(value: Any, available: set[str]):
            if isinstance(value, str):
                for match in PLACEHOLDER.finditer(value):
                    if not match.group(1).startswith("steps."):
                        continue
                    _, source, field = match.group(1).split(".", 2)
                    if source in results:
                        self._step_value(results, source, field)
                    elif source not in available:
                        raise ValueError(f"Binding source {source!r} must be a completed step or an earlier step in this plan.")
            elif isinstance(value, (list, tuple)):
                for item in value:
                    check(item, available)
            elif isinstance(value, dict):
                for item in value.values():
                    check(item, available)
        check([*step.arguments, step.vault_id, *[item.value for item in step.expect]], pending)
        if step.wait_for:
            check(step.wait_for.arguments, pending | {step.id})

    def remember_response(self, step: Step, data: Any) -> None:
        if step.command not in (["kms", "management", "vault", "get"], ["kms", "management", "vault", "list"]):
            return
        if any(arg.split("=", 1)[0] == "--query" for arg in step.arguments) or not isinstance(data, dict):
            return
        values = data.get("data")
        for value in values if isinstance(values, list) else [values]:
            if not isinstance(value, dict) or not value.get("management-endpoint"):
                continue
            vault_id = value.get("id", "")
            endpoint = management_endpoint(vault_id, value["management-endpoint"], self.settings.region)
            if vault_id in self.vault_endpoints and self.vault_endpoints[vault_id] != endpoint:
                raise ValueError("Vault management endpoint changed within this task; start a fresh discovery.")
            self.vault_endpoints[vault_id] = endpoint

    def key_endpoint(self, step: Step, results: dict[str, Any]) -> str | None:
        if not is_key_command(step.command):
            return None
        if not step.vault_id or "{{secret:" in step.vault_id:
            raise ValueError("KMS key command requires non-secret vault_id context.")
        vault_id = self._resolve(step.vault_id, results)
        if vault_id not in self.vault_endpoints:
            raise ValueError(f"No discovered management-endpoint for Vault {vault_id}. First run a discovery stage with kms management vault get --vault-id {vault_id}, without --query, then retry the key plan with vault_id context.")
        return management_endpoint(vault_id, self.vault_endpoints[vault_id], self.settings.region)

    def _environment(self) -> dict[str, str]:
        # Prevent inherited OCI CLI endpoint/default/auth overrides from changing the plan.
        env = {key: value for key, value in os.environ.items() if not key.upper().startswith("OCI_")}
        env["OCI_CLI_SUPPRESS_FILE_PERMISSIONS_WARNING"] = "True"
        return env

    def _flags(self) -> list[str]:
        return [
            "--config-file", str(self.settings.config_file), "--profile", self.settings.profile,
            "--region", self.settings.region, "--output", "json", "--no-retry",
            "--cli-rc-file", str(self.empty_rc),
            "--auth", "security_token" if self.settings.profile_uses_session() else "api_key",
        ]

    def help(self, command: list[str]) -> str:
        command = canonical_command(command)
        if not command or not all(COMMAND_WORD.fullmatch(word) for word in command):
            raise ValueError("Invalid help command path.")
        result = self._process([*command, "--help"], timeout=45)
        return self.redactor.text(result.stdout + result.stderr)[:14000]

    def _process(self, args: list[str], timeout: int) -> CommandResult:
        try:
            completed = subprocess.run(
                [self.settings.cli, *args], cwd=self.settings.root, env=self._environment(),
                stdin=subprocess.DEVNULL, capture_output=True, text=True,
                encoding="utf-8", errors="replace", shell=False, timeout=timeout,
            )
            stdout, stderr, code = completed.stdout, completed.stderr, completed.returncode
        except subprocess.TimeoutExpired:
            return CommandResult(124, None, "", "Command timed out. Cloud outcome is uncertain; reconcile before retrying.", "uncertain")
        except OSError as exc:
            return CommandResult(127, None, "", self.redactor.text(str(exc)), "local")
        try:
            data = json.loads(stdout)
        except (ValueError, TypeError):
            data = None
        # No raw output is retained by the agent, including newly returned secret fields.
        safe_data = self.redactor.clean(data)
        safe_stdout = json.dumps(safe_data) if data is not None else self.redactor.text(stdout)
        return CommandResult(code, safe_data, safe_stdout, self.redactor.text(stderr), classify(code, stdout, stderr))

    def execute(self, step: Step, results: dict[str, Any]) -> CommandResult:
        self.resolve_metadata(step)
        prepare_key(step)
        self.validate(step)
        endpoint = self.key_endpoint(step, results)
        arguments = [self._resolve(arg, results) for arg in step.arguments]
        resolved = step.model_copy(update={"arguments": arguments})
        self.validate(resolved, resolved=True)
        # OCI CLI rendering discards an empty list before it can apply --query.
        # Keep native query behavior for ordinary results. Only reconstruct a verified
        # empty array-list envelope when this known renderer case emits no stdout.
        query, index = None, 0
        while index < len(arguments):
            argument = arguments[index]
            if argument == "--query":
                if index + 1 == len(arguments):
                    raise ValueError("--query needs an expression.")
                query = arguments[index + 1]
                index += 2
            elif argument.startswith("--query="):
                query = argument.split("=", 1)[1]
                index += 1
            else:
                index += 1
        compiled = jmespath.compile(query) if query is not None else None
        timeout = self.settings.timeout
        # Preserve service-specific CLI waiters for legacy/unknown mappings, with
        # a completion budget independent of the short ordinary-command timeout.
        if any(arg.split("=", 1)[0] == "--wait-for-state" for arg in arguments):
            maximum = self.settings.wait_timeout
            for index, arg in enumerate(arguments):
                if arg == "--max-wait-seconds" and index + 1 < len(arguments):
                    maximum = int(arguments[index + 1])
                    break
                if arg.startswith("--max-wait-seconds="):
                    maximum = int(arg.split("=", 1)[1])
                    break
            else:
                arguments = [*arguments, "--max-wait-seconds", str(maximum)]
            if not 1 <= maximum <= self.settings.wait_timeout:
                raise ValueError("CLI waiter duration must fit wait_timeout_seconds.")
            timeout = max(timeout, maximum + 30)
        endpoint_flags = ["--endpoint", endpoint] if endpoint is not None else []
        result = self._process([*step.command, *arguments, *self._flags(), *endpoint_flags], timeout)
        if result.code == 0 and result.data is None and not result.stdout.strip() and self._only_runtime_warnings(result.stderr):
            from .response_schema import response_schema
            metadata = response_schema(step.command)
            if metadata["known"] and step.command[-1] == "list" and metadata["data_type"] == "array":
                result.data = {"data": []}
                result.output_note = "Successful SDK-confirmed array-list operation: OCI CLI renderer omitted the empty data list; restored the data=[] envelope."
                if compiled is not None:
                    result.data = compiled.search(result.data)
                    result.output_note += " Query evaluated locally against that empty envelope."
                result.stdout = json.dumps(result.data)
        return result

    @staticmethod
    def _only_runtime_warnings(stderr: str) -> bool:
        warning = False
        for line in stderr.splitlines():
            if not line.strip():
                continue
            if re.match(r".+\.py:\d+:\s*\w*Warning:", line):
                warning = True
            elif not (warning and line[:1].isspace()):
                return False
        return True
