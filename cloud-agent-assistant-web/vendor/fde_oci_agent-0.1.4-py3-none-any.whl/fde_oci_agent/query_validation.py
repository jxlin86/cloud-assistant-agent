"""Check common OCI JMESPath projections without changing their meaning."""
from __future__ import annotations

import re

import jmespath

from .response_schema import response_schema
from .schema import Step, path_parts
from .task_inputs import option_value


def _fields(node: dict):
    if node.get("type") == "field":
        yield node["value"]
    for child in node.get("children", []):
        yield from _fields(child)
        # Tag/metadata dictionaries have user-defined, case-sensitive keys.
        if node.get("type") == "subexpression" and child.get("type") == "field" and child.get("value") in {"freeform-tags", "defined-tags", "metadata", "headers"}:
            break


def validate_query(step: Step) -> None:
    expression = option_value(step.arguments, "--query")
    if expression is None:
        return
    try:
        node = jmespath.compile(expression).parsed
    except jmespath.exceptions.JMESPathError as exc:
        raise ValueError(f"Invalid --query JMESPath expression: {exc}") from exc
    metadata = response_schema(step.command)
    if metadata["known"]:
        canonical = set(metadata.get("fields", {})) | set(metadata.get("item_fields", {})) | {"data"}
        normalize = lambda value: re.sub(r"[-_]", "", value).lower()
        for field in _fields(node):
            if field in canonical:
                continue
            equivalent = next((value for value in canonical if normalize(value) == normalize(field)), None)
            if equivalent:
                raise ValueError(f"--query uses '{field}', but OCI CLI JSON uses '{equivalent}'. "
                                 "Quote hyphenated field names, e.g. data[?\"db-name\"=='NAME'].id, or prefer native filter flags.")
    # JMESPath output is the new JSON root; it is not wrapped in another data object.
    root_keys = None
    kind = node.get("type")
    if kind == "multi_select_dict":
        root_keys = {child["value"] for child in node["children"]}
    elif kind in {"projection", "filter_projection", "flatten", "multi_select_list"}:
        root_keys = set()
    elif kind == "field" and node.get("value") == "data" and metadata["known"]:
        root_keys = set() if metadata["data_type"] == "array" else set(metadata["fields"])
    elif kind == "subexpression" and [c.get("value") for c in node.get("children", [])] == ["data", "items"]:
        if metadata["known"] and metadata["data_type"] == "array":
            raise ValueError("The query source is an array at data, not a collection at data.items.")
        root_keys = set()
    elif kind == "function_expression" and node.get("value") in {"length", "contains", "join", "to_string", "to_number", "type", "sum", "avg", "keys", "values", "sort", "sort_by", "map"}:
        root_keys = set()
    if root_keys is not None:
        for check in step.expect:
            parts = path_parts(check.path)
            head = parts[0] if parts else None
            if head is None or head.isdigit():
                continue
            if head not in root_keys:
                raise ValueError(f"Expectation '{check.path}' does not match the --query result root. "
                                 "A projected list has no data wrapper: use path '$' to check the entire result, e.g. '$ empty', or preserve the data envelope in the query.")
